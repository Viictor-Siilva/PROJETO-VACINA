const db = require('../config/database');

class DashboardController {
  // Obter estatísticas gerais da dashboard
  static getEstatisticas(req, res, next) {
    const stats = {};

    // 1. Total de vacinas e estoque baixo
    db.get('SELECT COUNT(*) as total FROM vacinas', (err, result) => {
      if (err) return next(err);
      stats.totalVacinas = result.total;

      // 2. Vacinas mais populares (top 5)
      db.all(`
        SELECT v.nome, COUNT(r.id) as aplicacoes
        FROM vacinas v
        LEFT JOIN registros r ON v.nome = r.tipo_vacina
        GROUP BY v.nome
        ORDER BY aplicacoes DESC
        LIMIT 5
      `, (err, populares) => {
        if (err) return next(err);
        stats.vacinasPopulares = populares;

        // 3. Aplicações de hoje
        const hoje = new Date().toISOString().split('T')[0];
        db.get(`
          SELECT COUNT(*) as total
          FROM registros
          WHERE DATE(data_aplicacao) = ?
        `, [hoje], (err, result) => {
          if (err) return next(err);
          stats.aplicacoesHoje = result.total;

          // 4. Agendamentos pendentes
          db.get(`
            SELECT COUNT(*) as total
            FROM agendamentos
            WHERE DATE(data_vacinacao) >= DATE('now')
          `, (err, result) => {
            if (err) return next(err);
            stats.agendamentosPendentes = result.total;

            // 5. Total de funcionários
            db.get('SELECT COUNT(*) as total FROM funcionarios', (err, result) => {
              if (err) return next(err);
              stats.totalFuncionarios = result.total;

              res.json(stats);
            });
          });
        });
      });
    });
  }

  // Obter aplicações dos últimos 7 dias
  static getAplicacoes7Dias(req, res, next) {
    db.all(`
      SELECT DATE(data_aplicacao) as data, COUNT(*) as total
      FROM registros
      WHERE DATE(data_aplicacao) >= DATE('now', '-7 days')
      GROUP BY DATE(data_aplicacao)
      ORDER BY data ASC
    `, (err, rows) => {
      if (err) return next(err);

      // Preencher dias sem aplicações
      const resultado = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const dataStr = d.toISOString().split('T')[0];
        const registro = rows.find(r => r.data === dataStr);
        resultado.push({
          data: dataStr,
          total: registro ? registro.total : 0
        });
      }

      res.json(resultado);
    });
  }

  // Obter próximos agendamentos
  static getProximosAgendamentos(req, res, next) {
    db.all(`
      SELECT *
      FROM agendamentos
      WHERE DATE(data_vacinacao) >= DATE('now')
      ORDER BY data_vacinacao ASC
      LIMIT 5
    `, (err, agendamentos) => {
      if (err) return next(err);
      res.json(agendamentos);
    });
  }

  // Obter status de vacinação dos funcionários
  static getStatusVacinacao(req, res, next) {
    // Contar funcionários totalmente vacinados (3+ doses)
    db.get(`
      SELECT COUNT(DISTINCT funcionario) as total
      FROM cartao_vacina
      GROUP BY funcionario
      HAVING COUNT(*) >= 3
    `, (err, totalmente) => {
      if (err) return next(err);
      const totalmenteVacinados = totalmente ? totalmente.total : 0;

      // Contar funcionários parcialmente vacinados (1-2 doses)
      db.get(`
        SELECT COUNT(DISTINCT funcionario) as total
        FROM cartao_vacina
        GROUP BY funcionario
        HAVING COUNT(*) BETWEEN 1 AND 2
      `, (err, parcialmente) => {
        if (err) return next(err);
        const parcialmenteVacinados = parcialmente ? parcialmente.total : 0;

        // Total de funcionários
        db.get('SELECT COUNT(*) as total FROM funcionarios', (err, result) => {
          if (err) return next(err);
          const totalFuncionarios = result.total;
          const naoVacinados = totalFuncionarios - totalmenteVacinados - parcialmenteVacinados;

          res.json({
            naoVacinados: naoVacinados > 0 ? naoVacinados : 0,
            parcialmenteVacinados,
            totalmenteVacinados
          });
        });
      });
    });
  }

  // Obter métricas para sparklines
  static getMetricas(req, res, next) {
    const metricas = {};

    // Aplicações de hoje
    const hoje = new Date().toISOString().split('T')[0];
    db.get(`
      SELECT COUNT(*) as total
      FROM registros
      WHERE DATE(data_aplicacao) = ?
    `, [hoje], (err, result) => {
      if (err) return next(err);
      metricas.aplicacoesHoje = result.total;

      // Agendamentos pendentes
      db.get(`
        SELECT COUNT(*) as total
        FROM agendamentos
        WHERE DATE(data_vacinacao) >= DATE('now')
      `, (err, result) => {
        if (err) return next(err);
        metricas.agendamentosPendentes = result.total;

        // Total de aplicações
        db.get('SELECT COUNT(*) as total FROM registros', (err, result) => {
          if (err) return next(err);
          metricas.totalAplicacoes = result.total;

          res.json(metricas);
        });
      });
    });
  }

  // Obter dados do cartão de vacina do usuário logado
  static getCartaoUsuario(req, res, next) {
    // Por enquanto, vamos usar o funcionário com ID 1 como exemplo
    // Em produção, isso viria do token de autenticação
    const funcionarioId = req.params.funcionarioId || 1;

    db.all(`
      SELECT *
      FROM cartao_vacina
      WHERE funcionario = ?
      ORDER BY data_aplicacao DESC
    `, [funcionarioId], (err, doses) => {
      if (err) return next(err);

      const totalDoses = doses.length;
      const proximaDose = doses.length > 0 ? '2025-05-21' : null; // Exemplo fixo

      res.json({
        dosesTomadas: totalDoses,
        totalDoses: 5, // Exemplo fixo
        proximaDose,
        doses
      });
    });
  }
}

module.exports = DashboardController;
