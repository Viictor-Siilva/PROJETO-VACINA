const express = require('express');
const router = express.Router();
const DashboardController = require('../controllers/dashboardController');

// Rota para estatísticas gerais
router.get('/estatisticas', DashboardController.getEstatisticas);

// Rota para aplicações dos últimos 7 dias
router.get('/aplicacoes-7dias', DashboardController.getAplicacoes7Dias);

// Rota para próximos agendamentos
router.get('/proximos-agendamentos', DashboardController.getProximosAgendamentos);

// Rota para status de vacinação
router.get('/status-vacinacao', DashboardController.getStatusVacinacao);

// Rota para métricas
router.get('/metricas', DashboardController.getMetricas);

// Rota para cartão do usuário
router.get('/cartao-usuario/:funcionarioId?', DashboardController.getCartaoUsuario);

module.exports = router;
