# 🚀 Guia de Início Rápido - Sistema UNIVAS

## ⚡ Começar em 3 Passos

### 1️⃣ Instalar Dependências
```bash
cd backend
npm install
```

### 2️⃣ Iniciar o Servidor
```bash
npm start
```

### 3️⃣ Acessar a Dashboard
Abra no navegador: **http://localhost:3000/index.html**

---

## ✅ O que Esperar

Quando o servidor iniciar, você verá:
```
Tabelas criadas ou já existentes
Servidor rodando na porta 3000
Acesse: http://localhost:3000
Conectado ao banco de dados SQLite
```

## 📊 Dashboard Integrada

A dashboard agora mostra dados REAIS do banco de dados:

- ✅ Total de vacinas cadastradas
- ✅ Vacinas mais aplicadas (gráfico)
- ✅ Aplicações dos últimos 7 dias
- ✅ Agendamentos pendentes
- ✅ Status de vacinação (gráfico de pizza)
- ✅ Métricas em tempo real

## 🎯 Principais Mudanças

| Antes | Depois |
|-------|--------|
| Dados fixos | Dados dinâmicos |
| Sem API | 6 endpoints REST |
| Estático | Tempo real |

## 📁 Arquivos Importantes

- `DOCUMENTACAO_INTEGRACAO.md` - Documentação técnica completa
- `README_ATUALIZACAO.md` - Detalhes das melhorias
- `backend/src/controllers/dashboardController.js` - Lógica da dashboard
- `frontend/js/script.js` - Frontend integrado

## 🔧 Comandos Úteis

### Desenvolvimento (auto-reload)
```bash
npm run dev
```

### Testar API
```bash
curl http://localhost:3000/dashboard/estatisticas
```

### Ver logs
Os logs aparecem no terminal onde você executou `npm start`

## 🆘 Problemas Comuns

**Porta 3000 já em uso?**
```bash
# Matar processo na porta 3000
killall node
# Ou mudar a porta no arquivo .env
PORT=3001
```

**Erro ao instalar dependências?**
```bash
# Limpar cache e reinstalar
rm -rf node_modules package-lock.json
npm install
```

## 📞 Precisa de Ajuda?

1. Consulte `DOCUMENTACAO_INTEGRACAO.md`
2. Verifique os logs do servidor
3. Teste os endpoints individualmente

---

**Pronto! Seu sistema está funcionando! 🎉**
