UniVac - Node.js Backend integrado com Frontend
------------------------------------------------
Pasta backend: scripts Node.js
Para executar:
  cd backend
  npm install
  copiar .env.example -> .env e ajustar
  criar banco: mysql -u root -p < db_schema.sql
  (opcional) seed: mysql -u root -p < seed.sql
  npm start
Abra http://localhost:3000
