// dashboard.js - API para comunicação com o backend da dashboard

const API_BASE_URL = 'http://localhost:3000';

// Função auxiliar para fazer requisições
async function fetchAPI(endpoint) {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`);
    if (!response.ok) {
      throw new Error(`Erro HTTP: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`Erro ao buscar dados de ${endpoint}:`, error);
    throw error;
  }
}

// API da Dashboard
const DashboardAPI = {
  // Obter estatísticas gerais
  async getEstatisticas() {
    return await fetchAPI('/dashboard/estatisticas');
  },

  // Obter aplicações dos últimos 7 dias
  async getAplicacoes7Dias() {
    return await fetchAPI('/dashboard/aplicacoes-7dias');
  },

  // Obter próximos agendamentos
  async getProximosAgendamentos() {
    return await fetchAPI('/dashboard/proximos-agendamentos');
  },

  // Obter status de vacinação
  async getStatusVacinacao() {
    return await fetchAPI('/dashboard/status-vacinacao');
  },

  // Obter métricas
  async getMetricas() {
    return await fetchAPI('/dashboard/metricas');
  },

  // Obter cartão do usuário
  async getCartaoUsuario(funcionarioId = 1) {
    return await fetchAPI(`/dashboard/cartao-usuario/${funcionarioId}`);
  }
};

// Exportar para uso em outros arquivos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = DashboardAPI;
}
