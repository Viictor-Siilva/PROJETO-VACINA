// script-integrado.js - Dashboard com integração ao backend

// ============================
// 1. Configurações de rotas
// ============================
const pages = [
  { name: "home", url: "index.html", keywords: ["início", "home", "principal"] },
  { name: "listar funcionario", url: "pages/TelaListarFuncionarios.html", keywords: ["funcionario", "funcionários", "listar funcionarios", "colaborador"] },
  { name: "listar vacinas", url: "pages/TelaListarVacinas.html", keywords: ["vacina", "vacinas", "listar", "todas as vacinas"] },
  { name: "registro vacina", url: "pages/TelaRegistroVacina.html", keywords: ["registro", "nova vacina", "adicionar vacina"] },
  { name: "agendamento vacina", url: "pages/TelaAgendamentoVacina.html", keywords: ["agendar", "agendamento", "vacina futura", "marcar vacina"] },
  { name: "filtro vacinas", url: "pages/TelaFiltroVacinas.html", keywords: ["filtro", "buscar vacina", "procurar vacina"] },
  { name: "cartão vacina", url: "pages/TelaCartaoVacinaAtual.html", keywords: ["cartão", "meu cartão", "vacinas tomadas", "histórico"] },
  { name: "perfil", url: "pages/TelaPerfilUsuario.html", keywords: ["usuario", "login", "entrar", "perfil"] }
];

// ============================
// 2. Configuração da API
// ============================
const API_BASE_URL = 'http://localhost:3000';

async function fetchAPI(endpoint) {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`);
    if (!response.ok) {
      throw new Error(`Erro HTTP: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`Erro ao buscar dados de ${endpoint}:`, error);
    return null;
  }
}

// ============================
// 3. Função de pesquisa
// ============================
function pesquisarPagina(event) {
  event.preventDefault();
  const input = event.target.querySelector("input[type='search']");
  const query = input.value.toLowerCase().trim();

  const foundPage = pages.find(page =>
    page.name.includes(query) || page.keywords.some(keyword => keyword.includes(query))
  );

  if (foundPage) {
    window.location.href = foundPage.url;
  } else {
    const sugestoes = pages
      .filter(p => p.keywords.some(k => k.includes(query)))
      .map(p => `<li><a href="${p.url}">${p.name}</a></li>`)
      .join("");

    const mensagem = sugestoes
      ? `<h2>Você quis dizer:</h2><ul>${sugestoes}</ul>`
      : `<h2>Nenhuma página encontrada para: <em>${query}</em></h2><p>Tente usar palavras como "vacina", "registro", "funcionário", etc.</p>`;

    localStorage.setItem("notFoundMensagem", mensagem);
    window.location.href = `pages/NotFound.html?search=${encodeURIComponent(query)}`;
  }
}

// ============================
// 4. Funções de inicialização com dados da API
// ============================

// 4.1 Listar Vacinas (gráfico de barras horizontal)
async function initListarVacinasCard() {
  try {
    const stats = await fetchAPI('/dashboard/estatisticas');
    if (!stats) {
      console.error('Não foi possível carregar estatísticas');
      return;
    }

    document.getElementById("totalVacinas").textContent = stats.totalVacinas || 0;
    
    const lowStock = 3; // Isso poderia vir da API também
    document.getElementById("lowStock").innerHTML =
      `<i class="bi bi-exclamation-triangle-fill text-warning"></i> ${lowStock} em estoque baixo`;

    const populares = stats.vacinasPopulares || [];
    
    if (populares.length > 0) {
      const ctx = document.getElementById("chartVacinasPopulares");
      new Chart(ctx, {
        type: "bar",
        data: {
          labels: populares.map(v => v.nome),
          datasets: [{ data: populares.map(v => v.aplicacoes) }]
        },
        options: {
          indexAxis: "y",
          plugins: { legend: { display: false } },
          scales: { x: { beginAtZero: true } },
          maintainAspectRatio: false,
          responsive: true
        }
      });
    }
  } catch (error) {
    console.error('Erro ao inicializar card de vacinas:', error);
  }
}

// 4.2 Cartão Vacina (progress bar)
async function initCartaoVacinaCard() {
  try {
    const cartao = await fetchAPI('/dashboard/cartao-usuario/1');
    if (!cartao) {
      console.error('Não foi possível carregar cartão de vacina');
      return;
    }

    const dosesTomadas = cartao.dosesTomadas || 0;
    const totalDoses = cartao.totalDoses || 5;
    const proximaDose = cartao.proximaDose || 'Não agendada';
    const pct = totalDoses > 0 ? Math.round((dosesTomadas / totalDoses) * 100) : 0;

    document.getElementById("dosesTomadas").textContent = dosesTomadas;
    document.getElementById("proximaDose").textContent = proximaDose;

    const bar = document.querySelector(".progress-bar-cartao");
    if (bar) {
      bar.style.width = pct + "%";
      bar.textContent = pct + "%";
    }
  } catch (error) {
    console.error('Erro ao inicializar cartão de vacina:', error);
  }
}

// 4.3 Registro de Aplicações (últimos 7 dias)
async function initRegistroAplicacoesCard() {
  try {
    const aplicacoes = await fetchAPI('/dashboard/aplicacoes-7dias');
    if (!aplicacoes) {
      console.error('Não foi possível carregar aplicações');
      return;
    }

    const counts = aplicacoes.map(a => a.total);
    const labels = aplicacoes.map(a => {
      const d = new Date(a.data);
      return `${d.getDate().toString().padStart(2, "0")}/${(d.getMonth() + 1).toString().padStart(2, "0")}`;
    });

    const aplicacoesHoje = counts.length > 0 ? counts[counts.length - 1] : 0;
    document.getElementById("aplicacoesHoje").textContent = aplicacoesHoje;

    const ctx = document.getElementById("chartAplicacoes7d");
    new Chart(ctx, {
      type: "line",
      data: { labels, datasets: [{ data: counts, fill: true, tension: 0.3, pointRadius: 3 }] },
      options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } },
        maintainAspectRatio: false,
        responsive: true
      }
    });
  } catch (error) {
    console.error('Erro ao inicializar registro de aplicações:', error);
  }
}

// 4.4 Agendamento de Vacinas (lista simples)
async function initAgendamentoVacinasCard() {
  try {
    const proximos = await fetchAPI('/dashboard/proximos-agendamentos');
    if (!proximos) {
      console.error('Não foi possível carregar agendamentos');
      return;
    }

    document.getElementById("agendPendentesCount").textContent = proximos.length;
    const list = document.getElementById("agendPendentesList");
    list.innerHTML = ''; // Limpar lista

    proximos.forEach(a => {
      const li = document.createElement("li");
      const data = new Date(a.data_vacinacao).toLocaleDateString('pt-BR');
      li.textContent = `${data} – ${a.nome_paciente}`;
      list.appendChild(li);
    });
  } catch (error) {
    console.error('Erro ao inicializar agendamentos:', error);
  }
}

// 4.5 Gráfico de setores de status de vacinação
async function initStatusChart() {
  try {
    const status = await fetchAPI('/dashboard/status-vacinacao');
    if (!status) {
      console.error('Não foi possível carregar status de vacinação');
      return;
    }

    const totalNaoVacinados = status.naoVacinados || 0;
    const totalParcialmente = status.parcialmenteVacinados || 0;
    const totalTotalmente = status.totalmenteVacinados || 0;

    const ctx = document.getElementById('statusChart').getContext('2d');

    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: [
          'Não vacinados',
          'Parcialmente vacinados',
          'Totalmente vacinados'
        ],
        datasets: [{
          data: [
            totalNaoVacinados,
            totalParcialmente,
            totalTotalmente
          ],
          backgroundColor: [
            '#dc3545', // vermelho
            '#0d6efd', // azul
            '#28a745'  // verde
          ],
          borderWidth: 1
        }]
      },
      options: {
        plugins: {
          legend: {
            position: 'bottom'
          }
        },
        responsive: true,
        maintainAspectRatio: false
      }
    });
  } catch (error) {
    console.error('Erro ao inicializar gráfico de status:', error);
  }
}

// 4.6 Mini Calendário (canvas)
function drawMiniCalendar() {
  const canvas = document.getElementById("miniCalendar");
  if (!canvas) return;
  
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const daysOfWeek = ["D", "S", "T", "Q", "Q", "S", "S"];
  const cellW = canvas.width / 7;
  const cellH = (canvas.height - 20) / 2;
  const hoje = new Date();

  ctx.font = "10px Arial";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  daysOfWeek.forEach((day, i) => {
    ctx.fillStyle = "#6c757d";
    ctx.fillText(day, (i + 0.5) * cellW, cellH / 2);
  });

  for (let i = 0; i < 7; i++) {
    const dia = new Date(); 
    dia.setDate(hoje.getDate() + i);
    const col = dia.getDay();
    const x = col * cellW + cellW / 2;
    const y = cellH + cellH / 2;
    ctx.fillStyle = i === 0 ? "#0d6efd" : "#212529";
    ctx.fillText(dia.getDate(), x, y);
  }
}

// 4.7 Sparklines (trends)
async function initSparklines() {
  try {
    const metricas = await fetchAPI('/dashboard/metricas');
    if (!metricas) {
      console.error('Não foi possível carregar métricas');
      return;
    }

    // Dados simulados para os gráficos de tendência
    const dataToday = [2, 5, 3, 6, 4, 7, metricas.aplicacoesHoje || 0];
    const dataPending = [10, 8, 12, 9, 11, 10, metricas.agendamentosPendentes || 0];
    const dataTotal = [20, 25, 30, 28, 32, 35, metricas.totalAplicacoes || 0];

    document.getElementById('metricToday').textContent = metricas.aplicacoesHoje || 0;
    document.getElementById('metricPending').textContent = metricas.agendamentosPendentes || 0;
    document.getElementById('metricTotal').textContent = metricas.totalAplicacoes || 0;

    createSparkline('sparklineToday', dataToday);
    createSparkline('sparklinePending', dataPending);
    createSparkline('sparklineTotal', dataTotal);
  } catch (error) {
    console.error('Erro ao inicializar sparklines:', error);
  }
}

// Função genérica de sparkline
function createSparkline(canvasId, data) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: Array(data.length).fill(''),
      datasets: [{
        data,
        borderWidth: 2,
        borderColor: 'white',
        pointRadius: 0,
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: { display: false },
        y: { display: false }
      },
      elements: {
        line: { capBezierPoints: true }
      }
    }
  });
}

// ============================
// 5. Notificações
// ============================
function initNotifications() {
  const btn = document.getElementById('btnNotifications');
  if (!btn) return;
  
  const badge = btn.querySelector('.badge');
  const toastEl = document.getElementById('notificationToast');
  const toastBody = document.getElementById('toastBody');
  const toastTime = document.getElementById('toastTime');
  
  if (!toastEl) return;
  
  const toast = new bootstrap.Toast(toastEl);

  // Exemplo de notificações (pode ser substituído por dados da API)
  const notifications = [
    { text: 'Paciente João Silva recebeu a dose 2 de Covid-19', time: 'há 5 min' },
    { text: 'Nova vacina "Influenza" adicionada ao catálogo', time: 'há 30 min' },
    { text: 'Agendamento pendente para Maria Souza em 01/05/2025', time: 'há 1 h' }
  ];

  function updateBadge() {
    if (badge) {
      badge.textContent = notifications.length;
    }
  }

  function populateToast() {
    if (toastBody) {
      toastBody.innerHTML = '';
      notifications.forEach(n => {
        const item = document.createElement('div');
        item.className = 'mb-2';
        item.innerHTML = `
          <div>${n.text}</div>
          <small class="text-muted">${n.time}</small>
        `;
        toastBody.appendChild(item);
      });
    }
    if (toastTime) {
      toastTime.textContent = new Date().toLocaleTimeString();
    }
  }

  btn.addEventListener('click', () => {
    populateToast();
    toast.show();
  });

  updateBadge();
}

// ============================
// 6. Inicialização principal
// ============================
window.addEventListener("DOMContentLoaded", () => {
  // Pesquisa no header
  const headerSearchForm = document.getElementById("headerSearchForm");
  if (headerSearchForm) {
    headerSearchForm.addEventListener("submit", pesquisarPagina);
  }

  // Toggle da sidebar
  const toggleButton = document.getElementById('toggleSidebar');
  const sidebar = document.getElementById('sidebar');
  if (toggleButton && sidebar) {
    toggleButton.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
    });
  }

  // Inicializa todos os componentes da dashboard
  initListarVacinasCard();
  initCartaoVacinaCard();
  initRegistroAplicacoesCard();
  initAgendamentoVacinasCard();
  initStatusChart();
  drawMiniCalendar();
  initSparklines();
  initNotifications();
});

// Função debounce para uso futuro
export function debounce(func, delay) {
  let timer;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => func.apply(this, args), delay);
  };
}
