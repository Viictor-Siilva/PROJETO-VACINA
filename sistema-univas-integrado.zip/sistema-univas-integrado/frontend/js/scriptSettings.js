// ============================
// Script de Configurações
// ============================

// Verifica se estamos na tela de configurações
if (window.location.pathname.includes("Settings.html")) {
  
  // ============================
  // 1. Carregar configurações salvas
  // ============================
  function carregarConfiguracoes() {
    const user = JSON.parse(localStorage.getItem("usuarioLogado"));
    const config = JSON.parse(localStorage.getItem("configuracoes")) || {
      notificacaoEmail: true,
      notificacaoApp: false,
      modoEscuro: false
    };

    // Carregar dados do usuário
    if (user) {
      document.getElementById("inputName").value = user.nome || "";
      document.getElementById("inputEmail").value = user.email || "";
    }

    // Carregar configurações de notificação e tema
    document.getElementById("switchEmail").checked = config.notificacaoEmail;
    document.getElementById("switchApp").checked = config.notificacaoApp;
    document.getElementById("switchTheme").checked = config.modoEscuro;

    // Aplicar tema se estiver ativo
    if (config.modoEscuro) {
      aplicarModoEscuro();
    }
  }

  // ============================
  // 2. Salvar configurações em tempo real
  // ============================
  
  // Atualizar notificação por email
  document.getElementById("switchEmail").addEventListener("change", function(e) {
    const config = JSON.parse(localStorage.getItem("configuracoes")) || {};
    config.notificacaoEmail = e.target.checked;
    localStorage.setItem("configuracoes", JSON.stringify(config));
    
    mostrarFeedback(`Notificações por e-mail ${e.target.checked ? 'ativadas' : 'desativadas'}`, 'success');
  });

  // Atualizar notificação no app
  document.getElementById("switchApp").addEventListener("change", function(e) {
    const config = JSON.parse(localStorage.getItem("configuracoes")) || {};
    config.notificacaoApp = e.target.checked;
    localStorage.setItem("configuracoes", JSON.stringify(config));
    
    mostrarFeedback(`Notificações no aplicativo ${e.target.checked ? 'ativadas' : 'desativadas'}`, 'success');
  });

  // Atualizar tema (modo escuro)
  document.getElementById("switchTheme").addEventListener("change", function(e) {
    const config = JSON.parse(localStorage.getItem("configuracoes")) || {};
    config.modoEscuro = e.target.checked;
    localStorage.setItem("configuracoes", JSON.stringify(config));
    
    if (e.target.checked) {
      aplicarModoEscuro();
      mostrarFeedback('Modo escuro ativado', 'success');
    } else {
      removerModoEscuro();
      mostrarFeedback('Modo claro ativado', 'success');
    }
  });

  // ============================
  // 3. Aplicar/Remover Modo Escuro
  // ============================
  function aplicarModoEscuro() {
    document.body.classList.add('modo-escuro');
    document.body.style.backgroundColor = '#1a1a1a';
    document.body.style.color = '#ffffff';
    
    // Aplicar em cards
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
      card.style.backgroundColor = '#2d2d2d';
      card.style.color = '#ffffff';
    });

    // Aplicar em inputs
    const inputs = document.querySelectorAll('.form-control');
    inputs.forEach(input => {
      input.style.backgroundColor = '#3d3d3d';
      input.style.color = '#ffffff';
      input.style.borderColor = '#555';
    });
  }

  function removerModoEscuro() {
    document.body.classList.remove('modo-escuro');
    document.body.style.backgroundColor = '';
    document.body.style.color = '';
    
    // Remover de cards
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
      card.style.backgroundColor = '';
      card.style.color = '';
    });

    // Remover de inputs
    const inputs = document.querySelectorAll('.form-control');
    inputs.forEach(input => {
      input.style.backgroundColor = '';
      input.style.color = '';
      input.style.borderColor = '';
    });
  }

  // ============================
  // 4. Atualizar dados do perfil
  // ============================
  async function atualizarPerfil() {
    const user = JSON.parse(localStorage.getItem("usuarioLogado"));
    
    if (!user) {
      mostrarFeedback('Você precisa estar logado para atualizar o perfil', 'danger');
      return;
    }

    const nome = document.getElementById("inputName").value.trim();
    const email = document.getElementById("inputEmail").value.trim();

    if (!nome || !email) {
      mostrarFeedback('Por favor, preencha todos os campos', 'warning');
      return;
    }

    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      mostrarFeedback('Por favor, insira um e-mail válido', 'warning');
      return;
    }

    const atualizado = { ...user, nome, email };

    try {
      const response = await fetch(`http://localhost:3000/funcionarios/${user.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(atualizado),
      });

      if (response.ok) {
        localStorage.setItem("usuarioLogado", JSON.stringify(atualizado));
        mostrarFeedback('Perfil atualizado com sucesso!', 'success');
        
        // Atualizar nome na sidebar
        atualizarNomeSidebar(nome);
      } else {
        mostrarFeedback('Erro ao atualizar perfil', 'danger');
      }
    } catch (err) {
      console.error(err);
      mostrarFeedback('Erro ao conectar com o servidor', 'danger');
    }
  }

  // ============================
  // 5. Alterar senha
  // ============================
  async function alterarSenha(event) {
    event.preventDefault();
    
    const user = JSON.parse(localStorage.getItem("usuarioLogado"));
    
    if (!user) {
      mostrarFeedback('Você precisa estar logado', 'danger');
      return;
    }

    const senhaAtual = document.getElementById("currentPassword").value;
    const novaSenha = document.getElementById("newPassword").value;
    const confirmaSenha = document.getElementById("confirmPassword").value;

    if (!senhaAtual || !novaSenha || !confirmaSenha) {
      mostrarFeedback('Por favor, preencha todos os campos de senha', 'warning');
      return;
    }

    if (senhaAtual !== user.senha) {
      mostrarFeedback('Senha atual incorreta', 'danger');
      return;
    }

    if (novaSenha.length < 6) {
      mostrarFeedback('A nova senha deve ter pelo menos 6 caracteres', 'warning');
      return;
    }

    if (novaSenha !== confirmaSenha) {
      mostrarFeedback('A nova senha e a confirmação não coincidem', 'danger');
      return;
    }

    const atualizado = { ...user, senha: novaSenha };

    try {
      const response = await fetch(`http://localhost:3000/funcionarios/${user.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(atualizado),
      });

      if (response.ok) {
        localStorage.setItem("usuarioLogado", JSON.stringify(atualizado));
        mostrarFeedback('Senha alterada com sucesso!', 'success');
        
        // Limpar campos
        document.getElementById("currentPassword").value = "";
        document.getElementById("newPassword").value = "";
        document.getElementById("confirmPassword").value = "";
        
        // Fechar collapse
        const collapseElement = document.getElementById("collapsePassword");
        const bsCollapse = bootstrap.Collapse.getInstance(collapseElement);
        if (bsCollapse) {
          bsCollapse.hide();
        }
      } else {
        mostrarFeedback('Erro ao alterar senha', 'danger');
      }
    } catch (err) {
      console.error(err);
      mostrarFeedback('Erro ao conectar com o servidor', 'danger');
    }
  }

  // ============================
  // 6. Funções auxiliares
  // ============================
  function mostrarFeedback(mensagem, tipo) {
    // Remover alertas anteriores
    const alertaAnterior = document.querySelector('.alert-feedback');
    if (alertaAnterior) {
      alertaAnterior.remove();
    }

    // Criar novo alerta
    const alerta = document.createElement('div');
    alerta.className = `alert alert-${tipo} alert-dismissible fade show alert-feedback`;
    alerta.style.position = 'fixed';
    alerta.style.top = '20px';
    alerta.style.right = '20px';
    alerta.style.zIndex = '9999';
    alerta.style.minWidth = '300px';
    alerta.innerHTML = `
      ${mensagem}
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alerta);

    // Auto-remover após 5 segundos
    setTimeout(() => {
      if (alerta.parentElement) {
        alerta.remove();
      }
    }, 5000);
  }

  function atualizarNomeSidebar(nome) {
    const nomesSidebar = document.querySelectorAll('.sidebar .text-white.small');
    nomesSidebar.forEach(el => {
      if (el.innerHTML.includes('<br>')) {
        el.innerHTML = `${nome}<br>${el.innerHTML.split('<br>')[1]}`;
      }
    });
  }

  // ============================
  // 7. Event Listeners
  // ============================
  
  // Botão "Salvar todas as alterações"
  const btnSalvarTudo = document.querySelector('.btn-action');
  if (btnSalvarTudo) {
    btnSalvarTudo.addEventListener('click', function(e) {
      e.preventDefault();
      atualizarPerfil();
    });
  }

  // Formulário de alteração de senha
  const formSenha = document.querySelector('#collapsePassword form');
  if (formSenha) {
    formSenha.addEventListener('submit', alterarSenha);
  }

  // ============================
  // 8. Inicialização
  // ============================
  document.addEventListener('DOMContentLoaded', carregarConfiguracoes);
  
  // Carregar imediatamente se o DOM já estiver pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', carregarConfiguracoes);
  } else {
    carregarConfiguracoes();
  }
}
