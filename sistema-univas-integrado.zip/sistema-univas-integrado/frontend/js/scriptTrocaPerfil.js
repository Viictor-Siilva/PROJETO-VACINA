// ============================
// Script de Troca de Perfil
// ============================

// ============================
// 1. Inicialização e carregamento de usuários
// ============================
async function carregarUsuariosDisponiveis() {
  try {
    const response = await fetch('http://localhost:3000/funcionarios');
    if (response.ok) {
      const usuarios = await response.json();
      return usuarios;
    }
  } catch (error) {
    console.error('Erro ao carregar usuários:', error);
  }
  return [];
}

// ============================
// 2. Criar modal de troca de perfil
// ============================
function criarModalTrocaPerfil() {
  // Verificar se o modal já existe
  if (document.getElementById('modalTrocaPerfil')) {
    return;
  }

  const modalHTML = `
    <div class="modal fade" id="modalTrocaPerfil" tabindex="-1" aria-labelledby="modalTrocaPerfilLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header bg-success text-white">
            <h5 class="modal-title" id="modalTrocaPerfilLabel">
              <i class="bi bi-person-circle me-2"></i>Trocar Perfil
            </h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fechar"></button>
          </div>
          <div class="modal-body">
            <p class="text-muted mb-3">Selecione um perfil para alternar:</p>
            <div id="listaUsuarios" class="list-group">
              <div class="text-center py-3">
                <div class="spinner-border text-success" role="status">
                  <span class="visually-hidden">Carregando...</span>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          </div>
        </div>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', modalHTML);
}

// ============================
// 3. Preencher lista de usuários no modal
// ============================
async function preencherListaUsuarios() {
  const listaContainer = document.getElementById('listaUsuarios');
  const usuarioAtual = JSON.parse(localStorage.getItem('usuarioLogado'));
  
  if (!listaContainer) return;

  const usuarios = await carregarUsuariosDisponiveis();

  if (usuarios.length === 0) {
    listaContainer.innerHTML = `
      <div class="alert alert-warning" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>
        Nenhum usuário disponível para troca.
      </div>
    `;
    return;
  }

  listaContainer.innerHTML = '';

  usuarios.forEach(usuario => {
    const isAtual = usuarioAtual && usuarioAtual.id === usuario.id;
    
    const itemHTML = `
      <button 
        type="button" 
        class="list-group-item list-group-item-action d-flex align-items-center justify-content-between ${isAtual ? 'active' : ''}"
        onclick="trocarParaUsuario(${usuario.id})"
        ${isAtual ? 'disabled' : ''}
      >
        <div class="d-flex align-items-center gap-3">
          <img src="/public/icons/usuario-do-circulo.svg" 
               alt="Avatar" 
               class="rounded-circle ${isAtual ? '' : 'bg-light p-2'}" 
               style="width: 40px; height: 40px; ${isAtual ? 'filter: invert(1);' : ''}"
          >
          <div>
            <div class="fw-bold">${usuario.nome}</div>
            <small class="text-muted">${usuario.cargo || 'Funcionário'}</small>
          </div>
        </div>
        ${isAtual ? '<span class="badge bg-light text-success">Atual</span>' : '<i class="bi bi-arrow-right-circle"></i>'}
      </button>
    `;
    
    listaContainer.insertAdjacentHTML('beforeend', itemHTML);
  });
}

// ============================
// 4. Trocar para outro usuário
// ============================
window.trocarParaUsuario = async function(userId) {
  try {
    const response = await fetch(`http://localhost:3000/funcionarios/${userId}`);
    
    if (response.ok) {
      const usuario = await response.json();
      
      // Salvar novo usuário no localStorage
      localStorage.setItem('usuarioLogado', JSON.stringify(usuario));
      
      // Fechar modal
      const modal = bootstrap.Modal.getInstance(document.getElementById('modalTrocaPerfil'));
      if (modal) {
        modal.hide();
      }
      
      // Mostrar feedback
      mostrarNotificacaoTroca(usuario.nome);
      
      // Recarregar página após 1 segundo
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } else {
      alert('Erro ao trocar de perfil. Tente novamente.');
    }
  } catch (error) {
    console.error('Erro ao trocar usuário:', error);
    alert('Erro ao conectar com o servidor.');
  }
};

// ============================
// 5. Mostrar notificação de troca
// ============================
function mostrarNotificacaoTroca(nomeUsuario) {
  const toast = document.createElement('div');
  toast.className = 'toast align-items-center text-white bg-success border-0';
  toast.style.position = 'fixed';
  toast.style.top = '20px';
  toast.style.right = '20px';
  toast.style.zIndex = '9999';
  toast.setAttribute('role', 'alert');
  toast.setAttribute('aria-live', 'assertive');
  toast.setAttribute('aria-atomic', 'true');
  
  toast.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">
        <i class="bi bi-check-circle-fill me-2"></i>
        Perfil alterado para: <strong>${nomeUsuario}</strong>
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  `;
  
  document.body.appendChild(toast);
  
  const bsToast = new bootstrap.Toast(toast, { delay: 3000 });
  bsToast.show();
  
  toast.addEventListener('hidden.bs.toast', () => {
    toast.remove();
  });
}

// ============================
// 6. Adicionar botão de troca de perfil no dropdown
// ============================
function adicionarBotaoTrocaPerfil() {
  // Encontrar todos os dropdowns de perfil
  const dropdowns = document.querySelectorAll('.dropdown-menu');
  
  dropdowns.forEach(dropdown => {
    // Verificar se já tem o item de troca de perfil
    if (dropdown.querySelector('.trocar-perfil-item')) {
      return;
    }
    
    // Verificar se é o dropdown do usuário (tem "Meu Perfil" ou "Sair")
    const temPerfilOuSair = dropdown.innerHTML.includes('Perfil') || dropdown.innerHTML.includes('Sair');
    
    if (temPerfilOuSair) {
      // Encontrar o divisor antes de "Sair"
      const divisor = dropdown.querySelector('hr.dropdown-divider');
      
      if (divisor) {
        // Adicionar item de troca de perfil antes do divisor
        const itemTroca = document.createElement('li');
        itemTroca.innerHTML = `
          <a class="dropdown-item trocar-perfil-item" href="#" onclick="abrirModalTrocaPerfil(event)">
            <i class="bi bi-arrow-left-right me-2"></i>Trocar Perfil
          </a>
        `;
        
        divisor.parentNode.insertBefore(itemTroca, divisor);
      }
    }
  });
}

// ============================
// 7. Abrir modal de troca de perfil
// ============================
window.abrirModalTrocaPerfil = function(event) {
  if (event) {
    event.preventDefault();
  }
  
  // Criar modal se não existir
  criarModalTrocaPerfil();
  
  // Preencher lista de usuários
  preencherListaUsuarios();
  
  // Abrir modal
  const modalElement = document.getElementById('modalTrocaPerfil');
  const modal = new bootstrap.Modal(modalElement);
  modal.show();
};

// ============================
// 8. Atualizar informações do usuário na sidebar
// ============================
function atualizarInfoUsuarioSidebar() {
  const usuario = JSON.parse(localStorage.getItem('usuarioLogado'));
  
  if (!usuario) return;
  
  // Atualizar nome do usuário na sidebar
  const nomesSidebar = document.querySelectorAll('.sidebar .text-white.small, .offcanvas-body .text-white.small');
  nomesSidebar.forEach(el => {
    if (el.innerHTML.includes('<br>')) {
      const partes = el.innerHTML.split('<br>');
      if (partes.length >= 2) {
        el.innerHTML = `${usuario.nome}<br>${partes[1]}`;
      }
    }
  });
  
  // Atualizar nome no dropdown do header
  const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
  dropdownToggles.forEach(toggle => {
    if (toggle.innerHTML.includes('Usuário') || toggle.querySelector('img[alt="Perfil"]')) {
      const img = toggle.querySelector('img');
      if (img) {
        toggle.innerHTML = '';
        toggle.appendChild(img);
        toggle.appendChild(document.createTextNode(usuario.nome.split(' ')[0]));
      }
    }
  });
}

// ============================
// 9. Inicialização
// ============================
document.addEventListener('DOMContentLoaded', function() {
  // Adicionar botão de troca de perfil nos dropdowns
  adicionarBotaoTrocaPerfil();
  
  // Atualizar informações do usuário
  atualizarInfoUsuarioSidebar();
  
  // Criar modal (mas não abrir)
  criarModalTrocaPerfil();
});

// Se o DOM já estiver carregado
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', function() {
    adicionarBotaoTrocaPerfil();
    atualizarInfoUsuarioSidebar();
    criarModalTrocaPerfil();
  });
} else {
  adicionarBotaoTrocaPerfil();
  atualizarInfoUsuarioSidebar();
  criarModalTrocaPerfil();
}
