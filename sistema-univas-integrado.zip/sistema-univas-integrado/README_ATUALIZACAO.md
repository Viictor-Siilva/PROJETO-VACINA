# Sistema UNIVAS - Atualização da Dashboard

## 🎯 O que foi feito?

A dashboard (página inicial) do sistema UNIVAS foi completamente integrada com o backend, substituindo os dados estáticos (hardcoded) por dados dinâmicos provenientes do banco de dados SQLite.

## ✨ Principais Melhorias

### Antes
- ❌ Dados fixos e simulados
- ❌ Sem conexão com o banco de dados
- ❌ Informações desatualizadas
- ❌ Impossível ver dados reais

### Depois
- ✅ Dados dinâmicos e em tempo real
- ✅ Totalmente integrado com o backend
- ✅ Informações sempre atualizadas
- ✅ Reflete o estado real do sistema

## 📦 Novos Arquivos Criados

### Backend
```
backend/src/controllers/dashboardController.js  - Lógica de negócio da dashboard
backend/src/routes/dashboardRoutes.js          - Rotas da API
```

### Frontend
```
frontend/api/dashboard.js                      - Módulo de comunicação com API
frontend/js/script.js                          - Script atualizado (backup em script.js.backup)
```

### Documentação
```
DOCUMENTACAO_INTEGRACAO.md                     - Documentação técnica completa
README_ATUALIZACAO.md                          - Este arquivo
```

## 🚀 Como Usar

### 1. Instalar Dependências

```bash
cd backend
npm install
```

### 2. Iniciar o Servidor

```bash
npm start
```

Você verá:
```
Tabelas criadas ou já existentes
Servidor rodando na porta 3000
Acesse: http://localhost:3000
Conectado ao banco de dados SQLite
```

### 3. Acessar a Dashboard

Abra seu navegador em: **http://localhost:3000/index.html**

## 📊 Funcionalidades da Dashboard

### 1. Estatísticas de Vacinas
- Total de vacinas cadastradas
- Vacinas em estoque baixo
- Top 5 vacinas mais aplicadas (gráfico de barras)

### 2. Cartão de Vacina do Usuário
- Doses tomadas
- Progresso de vacinação
- Próxima dose agendada

### 3. Registro de Aplicações
- Gráfico dos últimos 7 dias
- Aplicações realizadas hoje
- Tendência de aplicações

### 4. Agendamentos Pendentes
- Lista dos próximos 5 agendamentos
- Data e nome do paciente
- Contador de agendamentos

### 5. Status de Vacinação
- Gráfico de pizza mostrando:
  - Funcionários não vacinados
  - Parcialmente vacinados
  - Totalmente vacinados

### 6. Métricas Rápidas
- Mini gráficos (sparklines) com:
  - Aplicações de hoje
  - Agendamentos pendentes
  - Total de aplicações

## 🔌 Endpoints da API

Todos os endpoints estão disponíveis em `http://localhost:3000/dashboard/`:

| Endpoint | Descrição |
|----------|-----------|
| `/estatisticas` | Estatísticas gerais |
| `/aplicacoes-7dias` | Aplicações dos últimos 7 dias |
| `/proximos-agendamentos` | Próximos 5 agendamentos |
| `/status-vacinacao` | Status de vacinação dos funcionários |
| `/metricas` | Métricas para sparklines |
| `/cartao-usuario/:id` | Cartão de vacina de um funcionário |

## 🛠️ Tecnologias

- **Backend:** Node.js + Express + SQLite3
- **Frontend:** HTML5 + Bootstrap 5 + Chart.js + JavaScript
- **Banco de Dados:** SQLite

## 📝 Observações Importantes

### Convenção de Nomenclatura
O banco de dados usa `snake_case` para colunas:
- `data_aplicacao` ✅
- `tipo_vacina` ✅
- `nome_paciente` ✅

### Backup do Script Original
O arquivo original foi preservado em:
```
frontend/js/script.js.backup
```

### Estrutura do Banco
O banco de dados já vem populado com dados de exemplo para testes.

## 🐛 Solução de Problemas

### Erro: "SQLITE_ERROR: no such column"
**Causa:** Nomes de colunas incorretos
**Solução:** Verificar se está usando `snake_case` nas queries

### Erro: "Cannot GET /dashboard/..."
**Causa:** Servidor não está rodando
**Solução:** Execute `npm start` no diretório backend

### Erro: "CORS policy"
**Causa:** Requisições bloqueadas pelo navegador
**Solução:** O CORS já está configurado no backend

### Gráficos não aparecem
**Causa:** Chart.js não carregou
**Solução:** Verifique a conexão com internet (CDN do Chart.js)

## 📚 Documentação Adicional

Para informações técnicas detalhadas, consulte:
- `DOCUMENTACAO_INTEGRACAO.md` - Documentação completa da integração
- `backend/README.md` - Documentação do backend
- `frontend/README.md` - Documentação do frontend

## 🎓 Desenvolvimento Acadêmico

Este projeto foi desenvolvido como trabalho acadêmico para demonstrar:
- Integração frontend-backend
- Consumo de APIs REST
- Manipulação de banco de dados
- Visualização de dados com gráficos
- Desenvolvimento full-stack

## 📞 Suporte

Para dúvidas ou problemas:
1. Consulte a documentação técnica
2. Verifique os logs do servidor
3. Teste os endpoints individualmente

---

**Desenvolvido com ❤️ para o Sistema UNIVAS**

**Data:** 27/11/2025
**Versão:** 1.0.0
