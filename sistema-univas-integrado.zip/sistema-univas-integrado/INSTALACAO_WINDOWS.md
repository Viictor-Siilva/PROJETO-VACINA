# 🪟 Guia de Instalação - Windows

## 📋 Pré-requisitos

Antes de começar, você precisa ter instalado:

1. **Node.js** (versão 16 ou superior)
   - Download: https://nodejs.org/
   - Escolha a versão LTS (recomendada)

2. **Git Bash** ou **PowerShell** (já vem com Windows)

## 🚀 Instalação Passo a Passo

### 1️⃣ Extrair o Projeto

1. Extraia o arquivo `sistema-univas-integrado.zip`
2. Você terá uma pasta chamada `sistema-univas-integrado`
3. Abra esta pasta

### 2️⃣ Abrir Terminal

**Opção A - PowerShell:**
1. Dentro da pasta `sistema-univas-integrado`
2. Clique com botão direito segurando `Shift`
3. Selecione "Abrir janela do PowerShell aqui"

**Opção B - Explorador de Arquivos:**
1. Na barra de endereços, digite `cmd` e pressione Enter
2. Ou digite `powershell` e pressione Enter

### 3️⃣ Navegar até a pasta backend

```powershell
cd backend
```

### 4️⃣ Instalar Dependências

```powershell
npm install
```

Aguarde a instalação (pode demorar alguns minutos).

### 5️⃣ Iniciar o Servidor

```powershell
npm start
```

Você verá:
```
Tabelas criadas ou já existentes
Servidor rodando na porta 3000
Acesse: http://localhost:3000
Conectado ao banco de dados SQLite
```

### 6️⃣ Acessar a Dashboard

Abra seu navegador e acesse:
```
http://localhost:3000/index.html
```

## ✅ Pronto!

Seu sistema está funcionando! A dashboard agora mostra dados reais do banco de dados.

## 🔧 Comandos Úteis

### Parar o Servidor
Pressione `Ctrl + C` no terminal

### Reiniciar o Servidor
```powershell
npm start
```

### Modo Desenvolvimento (auto-reload)
```powershell
npm run dev
```

## 🆘 Problemas Comuns

### ❌ "npm não é reconhecido como comando"
**Solução:** Instale o Node.js (veja pré-requisitos)

### ❌ "Erro ao instalar dependências"
**Solução:**
```powershell
# Limpar cache
npm cache clean --force

# Deletar node_modules e reinstalar
Remove-Item -Recurse -Force node_modules
Remove-Item package-lock.json
npm install
```

### ❌ "Porta 3000 já está em uso"
**Solução:**
```powershell
# Encontrar processo na porta 3000
netstat -ano | findstr :3000

# Matar processo (substitua PID pelo número encontrado)
taskkill /PID <PID> /F
```

### ❌ "Cannot find module..."
**Solução:** Execute `npm install` novamente

## 📂 Estrutura de Pastas

```
sistema-univas-integrado/
├── backend/              ← Entre aqui para instalar
│   ├── src/
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── index.html
│   ├── js/
│   └── pages/
└── README.md
```

## 📚 Documentação

- `GUIA_INICIO_RAPIDO.md` - Início rápido
- `README_ATUALIZACAO.md` - Detalhes das melhorias
- `DOCUMENTACAO_INTEGRACAO.md` - Documentação técnica
- `LISTA_ALTERACOES.txt` - Lista de alterações

## 💡 Dicas

1. **Sempre execute os comandos dentro da pasta `backend`**
2. **Não feche o terminal enquanto estiver usando o sistema**
3. **Use `Ctrl + C` para parar o servidor antes de fechar**

## 🎯 Próximos Passos

Após iniciar o servidor, explore:
- Dashboard com dados reais
- Gráficos interativos
- Listagem de vacinas
- Agendamentos
- Perfil de usuários

---

**Precisa de ajuda?** Consulte a documentação completa nos arquivos `.md` do projeto.
