# Documentação da Integração Dashboard - Sistema UNIVAS

## Visão Geral

Este documento descreve as alterações realizadas para integrar a dashboard (home) com o backend do sistema de gerenciamento de vacinas UNIVAS. A dashboard agora exibe dados dinâmicos em tempo real provenientes do banco de dados SQLite.

## Alterações Realizadas

### 1. Backend - Novos Endpoints

Foi criado um novo controller `dashboardController.js` com os seguintes endpoints:

#### **GET /dashboard/estatisticas**
Retorna estatísticas gerais da dashboard.

**Resposta:**
```json
{
  "totalVacinas": 5,
  "vacinasPopulares": [
    { "nome": "Hepatite B", "aplicacoes": 2 },
    { "nome": "Gripe", "aplicacoes": 2 }
  ],
  "aplicacoesHoje": 0,
  "agendamentosPendentes": 6,
  "totalFuncionarios": 6
}
```

#### **GET /dashboard/aplicacoes-7dias**
Retorna o número de aplicações dos últimos 7 dias.

**Resposta:**
```json
[
  { "data": "2025-11-21", "total": 0 },
  { "data": "2025-11-22", "total": 0 },
  { "data": "2025-11-23", "total": 0 },
  { "data": "2025-11-24", "total": 0 },
  { "data": "2025-11-25", "total": 1 },
  { "data": "2025-11-26", "total": 2 },
  { "data": "2025-11-27", "total": 0 }
]
```

#### **GET /dashboard/proximos-agendamentos**
Retorna os próximos 5 agendamentos.

**Resposta:**
```json
[
  {
    "id": "53e7",
    "nome_paciente": "Bruno",
    "tipo_vacina": "Febre Amarela",
    "local_vacinacao": "Postinho - Pouso Alegre",
    "data_vacinacao": "2025-11-27",
    "created_at": "2025-11-26 03:16:50"
  }
]
```

#### **GET /dashboard/status-vacinacao**
Retorna o status de vacinação dos funcionários.

**Resposta:**
```json
{
  "naoVacinados": 4,
  "parcialmenteVacinados": 1,
  "totalmenteVacinados": 1
}
```

#### **GET /dashboard/metricas**
Retorna métricas para os sparklines.

**Resposta:**
```json
{
  "aplicacoesHoje": 0,
  "agendamentosPendentes": 6,
  "totalAplicacoes": 8
}
```

#### **GET /dashboard/cartao-usuario/:funcionarioId**
Retorna o cartão de vacina de um funcionário específico.

**Resposta:**
```json
{
  "dosesTomadas": 3,
  "totalDoses": 5,
  "proximaDose": "2025-05-21",
  "doses": [...]
}
```

### 2. Frontend - Arquivos Modificados

#### **frontend/js/script.js**
- **Backup criado:** `script.js.backup` (versão original com dados estáticos)
- **Nova versão:** Integrada com a API do backend
- **Principais mudanças:**
  - Adicionada configuração da API (`API_BASE_URL`)
  - Criada função `fetchAPI()` para chamadas HTTP
  - Todas as funções de inicialização agora são assíncronas e buscam dados reais
  - Tratamento de erros implementado

#### **frontend/api/dashboard.js** (NOVO)
Módulo centralizado para comunicação com o backend da dashboard.

**Funções disponíveis:**
```javascript
DashboardAPI.getEstatisticas()
DashboardAPI.getAplicacoes7Dias()
DashboardAPI.getProximosAgendamentos()
DashboardAPI.getStatusVacinacao()
DashboardAPI.getMetricas()
DashboardAPI.getCartaoUsuario(funcionarioId)
```

### 3. Arquivos Backend Criados

- **backend/src/controllers/dashboardController.js** - Controller com lógica de negócio
- **backend/src/routes/dashboardRoutes.js** - Definição das rotas
- **backend/src/app.js** - Atualizado para incluir as rotas da dashboard

## Como Executar o Projeto

### Pré-requisitos
- Node.js v22.13.0 ou superior
- npm instalado

### Passo 1: Instalar Dependências

```bash
cd backend
npm install
```

### Passo 2: Iniciar o Servidor

```bash
cd backend
npm start
```

Ou para desenvolvimento com auto-reload:

```bash
npm run dev
```

O servidor estará disponível em: `http://localhost:3000`

### Passo 3: Acessar a Dashboard

Abra o navegador e acesse:
```
http://localhost:3000/index.html
```

## Estrutura de Dados

### Banco de Dados SQLite

O projeto utiliza SQLite com as seguintes tabelas:

- **funcionarios** - Dados dos funcionários
- **vacinas** - Catálogo de vacinas
- **registros** - Registro de aplicações de vacinas
- **agendamentos** - Agendamentos futuros
- **cartao_vacina** - Cartão de vacina dos funcionários

### Convenção de Nomenclatura

**Importante:** O banco de dados utiliza `snake_case` para nomes de colunas:
- `data_aplicacao` (não `dataAplicacao`)
- `tipo_vacina` (não `tipoVacina`)
- `data_vacinacao` (não `dataVacinacao`)
- `nome_paciente` (não `nomePaciente`)

## Componentes da Dashboard

### 1. Card "Listar Vacinas"
- **Dados:** Total de vacinas, vacinas em estoque baixo, top 5 vacinas mais aplicadas
- **Gráfico:** Barras horizontais (Chart.js)
- **Endpoint:** `/dashboard/estatisticas`

### 2. Card "Cartão Vacina"
- **Dados:** Doses tomadas, total de doses, próxima dose
- **Visualização:** Barra de progresso
- **Endpoint:** `/dashboard/cartao-usuario/:id`

### 3. Card "Registro de Aplicações"
- **Dados:** Aplicações dos últimos 7 dias
- **Gráfico:** Linha temporal (Chart.js)
- **Endpoint:** `/dashboard/aplicacoes-7dias`

### 4. Card "Agendamento de Vacinas"
- **Dados:** Próximos 5 agendamentos
- **Visualização:** Lista
- **Endpoint:** `/dashboard/proximos-agendamentos`

### 5. Gráfico de Status de Vacinação
- **Dados:** Não vacinados, parcialmente vacinados, totalmente vacinados
- **Gráfico:** Pizza (Chart.js)
- **Endpoint:** `/dashboard/status-vacinacao`

### 6. Métricas (Sparklines)
- **Dados:** Aplicações hoje, agendamentos pendentes, total de aplicações
- **Gráfico:** Mini gráficos de linha
- **Endpoint:** `/dashboard/metricas`

## Tecnologias Utilizadas

### Backend
- **Node.js** v22.13.0
- **Express** v4.18.2 - Framework web
- **SQLite3** v5.1.6 - Banco de dados
- **CORS** v2.8.5 - Controle de acesso
- **dotenv** v16.3.1 - Variáveis de ambiente

### Frontend
- **HTML5** - Estrutura
- **Bootstrap 5.3.0** - Framework CSS
- **Bootstrap Icons** - Ícones
- **Chart.js** - Gráficos
- **JavaScript (Vanilla)** - Lógica de negócio

## Tratamento de Erros

Todos os endpoints possuem tratamento de erros que retorna:

```json
{
  "success": false,
  "error": "Mensagem de erro",
  "stack": "Stack trace (apenas em desenvolvimento)"
}
```

## Melhorias Futuras

1. **Autenticação:** Implementar sistema de login e tokens JWT
2. **WebSocket:** Atualização em tempo real dos dados
3. **Cache:** Implementar cache para reduzir carga no banco
4. **Paginação:** Adicionar paginação nos endpoints que retornam listas
5. **Filtros:** Permitir filtrar dados por período, funcionário, etc.
6. **Testes:** Adicionar testes unitários e de integração
7. **Docker:** Containerizar a aplicação
8. **CI/CD:** Implementar pipeline de deploy automatizado

## Suporte

Para dúvidas ou problemas, consulte:
- README.md do projeto
- Documentação do Express: https://expressjs.com/
- Documentação do Chart.js: https://www.chartjs.org/

## Licença

Este projeto foi desenvolvido como trabalho acadêmico para o sistema UNIVAS.

---

**Última atualização:** 27/11/2025
**Versão:** 1.0.0
